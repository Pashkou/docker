#!/bin/bash -e
docker system prune --all --force
docker volume prune --force