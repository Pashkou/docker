# DECENTAGE Digital Onboarding

[TOC]

## Docker Compose Overview

 Docker Container Diagram

![](docs/store-assets/DECENTAGE-dop-docker-diagram.png)

### Keycloak Gatekeeper Container

> Docker Container: keycloak

- All requests coming from the WAF will be routed through this reverse proxy (Single point of entry for DOP access)
- Integrates Keycloak through OpenID Connect (OIDC)
- If user is not authenticated a redirect to the login/registration page will be initiated
- If a user is authenticated, the token is valid and all claims for a given URL is fulfilled the request is routed (upstreamed) to the ninx web server (onboarding-nginx)
- Automatically delegates authentication, refresh and token issuance requests to Keycloak
- Appends the refresh and identity token to the cookie

### Keycloak

> Docker Container: keycloak

- Provides the IDM/IAM functionality used for DECENTAGE DOP (internal employees, prospects) 
- Manages the Single-Sign On (SSO Sessions)
- Issue OAuth2 token (OpenId Connect) upon successful authentication 

- Delegates storage of Group and Access to LDAP (OpenLDAP) 
-  Enables two-factor Authentication using TOTP via Google Authentication

### OpenLdap

- Holds the user details, groups, and passwords (excl. 2FA) 
- Provides the LDAP endpoints for Keycloak and Camunda Application to read and manage a restricted set of entries/fields. 
- Currently no LDAP web browser installed 

### Nginx

> Docker Container: onboarding-nginx

- Used as a reverse proxy to forward the incoming requests from the keycloak-gatekeeeper to onboarding-camunda
- Serves the static client resources (JS, HTML, CSS)
- Forwards the camunda related requests to onboarding-camunda (Token will be passed through) 

### Camunda Spring Application

>  Docker Container: onboarding-camunda

- Spring Boot application using Spring Security and Open Connect ID
- Receive, parse and verifies the issued tokens (access and identity tokens)
- Manages the login accounts directly through LDAP
	​		

## Docker Compose Configuration

Currently all variables which contain environment dependent values are centrally configured in a central, host specific docker .env file.

A sample environment configuration setup can be found here:

[hosts/dop-example.example.io/.env](hosts/dop-example.example.io/.env)
The variables will be directly documented in this file with the next release

> Don't forget to replace all sensitive value placeholders containing the value (\*\*\*\*\*\*\**\*\*) with the correct value used for the corresponding target environment. 

## Infrastructure information

### UI entry points
| Domain                               | Path                                     | Handled by container | Component               | Access scope          |
| :--------------------------------------- | -------------------- | ----------------------- | --------------------- | --------------------- |
| keycloak | /oauth | keycloak | Keycloak Admin | keycloak-admin |
| DOP | / |  |  |  |
|  | /back-office | Browser | DECENTAGE DOP Tasklist | See Backoffice roles |
| camunda     | /camunda/app/welcome/default/            | onboarding-camunda   | Camunda Admin		    | -  		|
| camunda | /camunda/app/admin/default/ | onboarding-camunda   | Camunda Admin		    | camunda-admin  		|
| camunda | /camunda/app/tasklist/default/ | onboarding-camunda   | Camunda Tasklist        | camunda-admin     	|
| camunda | /camunda/app/cockpit/default/ | onboarding-camunda   | Camunda Cockpit         | camunda-admin  	    |
|  |  |  |  |  |


### HTTP entry points

| Path                                     | Handled by container | Component               | Access scope          |
| ---------------------------------------- | -------------------- | ----------------------- | --------------------- |
| /camunda/rest/*                          | onboarding-camunda   | Camunda REST Endpoints  | Restricted            |
| /camunda/dop/*                           | onboarding-camunda   | DECENTAGE DOP REST Endpoints |                       |
| /camunda/forms/*                         | onboarding-camunda   | Embeeded Camunda Forms  | Public                |
| /camunda/oauth/*                         | onboarding-camunda   |                         | Public                |
|   | onboarding-camunda   | Camunda Admin		    | camunda-admin  		|

### Static HTTP Rresources

| Path             | Handled by container | Component                          | Access scope |
| ---------------- | -------------------- | ---------------------------------- | ------------ |
| /camunda/forms/* | onboarding-camunda   | Embeeded Camunda Forms             | Public       |
| /static/*        | onboarding-nginx     | Static Resources for DECENTAGE DOP UI's | Public       |

### REST Services in use

#### Consumed Camunda REST Services (onboarding-camunda)

| Path                                                         | HTTP Method | Description | Required Role           |
| ------------------------------------------------------------ | ----------- | ----------- | ----------------------- |
| /camunda/rest/engine/default/task/{taskId}                   | GET         |             | prospect, camunda-admin |
| /camunda/rest/engine/default/task/{taskId}/variables/{variableName} | GET         |             | prospect, camunda-admin |
| /camunda/rest/engine/default/task/{taskId}/form-variables    | GET         |             | prospect, camunda-admin |
| /camunda/rest/engine/default/case-execution                  | GET         |             | prospect, camunda-admin |
| /camunda/rest/engine/default/case-execution/{caseExId}/manual-start | GET         |             | prospect, camunda-admin |
| /camunda/rest/engine/default/case-execution/{caseExId}/complete | GET         |             | prospect, camunda-admin |
| /camunda/rest/engine/default/case-execution/{caseExId}/terminate | GET         |             | prospect, camunda-admin |
| /camunda/rest/engine/default/case-execution/{caseExId}/localVariables | GET         |             | prospect, camunda-admin |
| /camunda/online-screening                                    | GET         |             | prospect, camunda-admin |
| /camunda/api/engine/engine/default/*                         | GET         | cockpit     | camunda-admin           |
| /camunda/api/engine/engine/default/*                         | POST        | cockpit     | camunda-admin           |
| /camunda/api/engine/engine/default/*                         | DELETE      | cockpit     | camunda-admin           |

#### Consumed DECENTAGE DOP REST Endpoints (onboarding-camunda)

| Path                                                             | HTTP Method | Description | Required Role      |
| ---------------------------------------------------------------- | ----------- | ----------- | ------------------ |
| /camunda/dop/user-info                                           | GET         |             | camunda-onboarding |
| /camunda/dop/account/${resouce}                                  | POST        |             |                    |
| /camunda/dop/document/get/{id}                                   | GET         |             |                    |
| /camunda/dop/document/upload                                     | POST        |             |                    |
| /camunda/dop/file/download/{taskId}/{file}                       | GET         |             |                    |
| /camunda/dop/files/{file}                                        | GET         |             |                    |
| /camunda/dop/contracts/generate/{template}/{taskId}              | GET         |             |                    |
| /camunda/dop/contracts/generate/summary/{taskId}                 | GET         |             |                    |
| /camunda/dop/permissions/is_admin                                | GET         |             |                    |
| /camunda/dop/questionnaire/aml                                   | GET         |             |                    |
| /camunda/dop/subscribe                                           | GET         |             |                    |
| /camunda/dop/forms/{formName}.html                               | GET         |             |                    |
| /camunda/dop/forms/{formPath}/{formName}.html                    | GET         |             |                    |
| /camunda/dop/account-opening/account/{taskId}                    | GET         |             |                    |
| /camunda/dop/account-opening/account/{taskId}                    | POST        |             |                    |
| /camunda/dop/account-opening/account/{taskId}/index              | POST        |             |                    |
| /camunda/dop/account-opening/account/{taskId}/index              | DELETE      |             |                    |
| /camunda/dop/account-opening/account/{taskId}/index/file         | GET         |             |                    |
| /camunda/dop/account-opening/account/partner/{taskId}            | GET         |             |                    |
| /camunda/dop/account-opening/account/partner/{taskId}            | POST        |             |                    |
| /camunda/dop/account-opening/account/partner/{taskId}            | DELETE      |             |                    |
| /camunda/dop/account-opening/account/partner/{taskId}/index/file | GET         |             |                    |

### Session usage

Once authenticated through a user session, the user can navigate through the different application of the realm (SSO Session).

###### Session termination in Keycloak

The following three events will trigger a session termination within Keycloak:

1. User calls the logout action
2. Session Idle Timeout is reached
   - This means that if the user has performed no actions during a predefined amount of time (called idle tile) the session expires by itself
   - The default value is 30mn
3. Session max Duration has reached
   - This is the maximum time a session can last
   - the default value is 10h

###### Importance of session control – potential security vulnerability

As mentioned earlier, a user session allows to navigate through all the different application of the realm.

> It is very important being able to control user sessions, and to destroy the user session as soon a user no longer needs the session.
>

### Cookie usage

| Name                      | Container           | Domain :Path              | Lifespan          | Description                                                  |
| ------------------------- | ------------------- | ------------------------- | ----------------- | ------------------------------------------------------------ |
| AUTH_SESSION_ID           | keycloak            | /auth/realms/DECENTAGE-dop/    | Browser Session   | Keycloak creates the cookie `AUTH_SESSION_ID` with the format like `<session-id>.<owner-node-id>`when creating a new authentication session. This cookie is mainly used to bind an authenticated user to a node when using a load balancer (sticky session). |
| KC_RESTART                | keycloak            | /auth/realms/DECENTAGE-dop/    | Browser Session   | Internal cookie from Keycloak.                               |
| KC_START                  | keycloak            | /auth/realms/DECENTAGE-dop/    |                   |                                                              |
| KEYCLOAK_IDENTITY         |                     |                           | ?                 | ID of the authenticated user. Contains a token (JWT) with the user ids. This cookie lives with your browser session and can also be refreshed with SSO. (for example, if you change some of your personal data in the "Manage my account") |
| KEYCLOAK_SESSION          | keycloak            |                           |                   | The session id associated to the concerned realm.            |
| KEYCLOAK_LOCALE           |                     |                           | Browser Session   |                                                              |
| KEYCLOAK_REMEMBER _ME     |                     |                           |                   |                                                              |
| Oauth_token_request_state |                     |                           | Browser Session*  | Is part of the Oauth spec in order to avoid hacking of the redirect link after login |
| kc-state                  | keycloak-gatekeeper | ${gatekeeper_url}/        | Browser Session** | The keycloak gatekeeper stores the JWT (OpenId) **refresh token** encrypted in this cookie. This token that is transmitted by the login protocol (keycloak) allows the application to obtain a new access token after it expires. This refresh protocol is important in the situation of a compromised system. If access tokens are short lived, the whole system is only vulnerable to a stolen token for the lifetime of the access toke This cookie can be disabled when using a local store like Redis or Boltdb. |
| kc-access*                | keycloak-gatekeeper | ${gatekeeper_url}/        | Browser Session** | The keycloak gatekeeper stores the **identity token** (JWT/OpenId) token in this cookie. It allows the protected application to access to a resource. The identity token contains information about the user such as username, email, and other profile information. The *access token* is digitally signed by the realm and contains access information (like user role mappings) that the application can use to determine what resources the user is allowed to access on the application. Is part of the OpenID Connect specification. The token can also be encrypted if necessary by setting config param *enable-encrypted-token* |
| kc-restart                | keycloak-gatekeeper | ${gatekeeper_url}/        |                   | This is an an JWT token that is stored as a cookie so that if there is a client timeout, then the authentication session can be restarted. |
| kc-callback-*             |                     |                           |                   | Client side cookie added by the OIDC Javascript adapter through keycloak used to |
| request-uri               |                     |                           |                   | This parameter enables OpenID Connect parameters to be passed by reference. The *"request_uri"* value is a URL using the https scheme referencing a resource containing a Request Object value, which is a JWT containing the request parameters |
| ?                         |                     |                           |                   |                                                              |
| JSESSIONID                | onboarding-camunda  | ${gatekeeper_url}/camunda |                   | The http sesssion id used to bind servelt session to a specific user. Since |
|                           |                     |                           |                   |                                                              |

*You can decode and view jwt tokens [jwt.io](https://jwt.io/) 

** By default the access and refresh cookies are session-only and disposed of on browser close; you can disable this feature using the `--enable-session-cookies` option.



***It is important to note that *access* tokens are usually short lived and often expired after only minutes. The additional *refresh*token that was transmitted by the login protocol allows the application to obtain a new access token after it expires. This refresh protocol is important in the situation of a compromised system. If access tokens are short lived, the whole system is only vulnerable to a stolen token for the lifetime of the access token. Future refresh token requests will fail if an admin has revoked access. This makes things more secure and more scalable.

*** Refresh token is subject to `SSO Session Idle timeout` (20mn) and `SSO Session Max lifespan ` (10hours) 

Keep in mind [browser cookie limits](http://browsercookielimits.squawky.net/) if you use access or refresh tokens in the browser cookie. Keycloak-generic-adapter divides the cookie automatically if your cookie is longer than 4093 bytes. Real size of the cookie depends on the content of the issued access token. Also, encryption might add additional bytes to the cookie size. If you have large cookies (>200 KB), you might reach browser cookie limits.

All cookies are part of the header request, so you might find a problem with the max headers size limits in your infrastructure (some load balancers have very low this value, such as 8 KB). Be sure that all network devices have sufficient header size limits. Otherwise, your users won’t be able to obtain an access token.

Cookies

Keycloak creates the cookie `AUTH_SESSION_ID` with the format like `<session-id>.<owner-node-id>`


### Usage of Session Storage in Browser

| Name                      | Container                  | Lifespan        | Description |
| ------------------------- | -------------------------- | --------------- | ----------- |
| DECENTAGE_register             | keycloak (theme)           | Browser Session |             |
| DECENTAGE_TASK                 | DECENTAGE-onboarding-nginx (JS) | Browser Session |             |
| DECENTAGE_questionnaire_form   | DECENTAGE-onboarding-nginx (JS) | Browser Session |             |

DECENTAGE_register flag used to redirect to register page in keycloak, when you get to login page first time. (Keycloak always redirect to login page, but we need to get to register page first time.)

DECENTAGE_TASK flag used to store processInstanceId and processDefinitionId after process start submit, to get actual tasks for user.

DECENTAGE_questionnaire_form flag used to store current step in Questionaire form, if you refresh page.

### Token and Session termination

It is crucial that the expiry of any session and token is well understood and that the timeout/expiry is  coordinated. 

|              | Container          | Component | Usage                                                        | Config                         |
| ------------ | ------------------ | --------- | ------------------------------------------------------------ | ------------------------------ |
| HTTP Session | onboarding-camunda |           | Used for the Camunda Admin UI. DECENTAGE DOP Application only uses REST services an should therefore | SERVER_SERVLET_SESSION_TIMEOUT |
|              |                    |           |                                                              |                                |
|              |                    |           |                                                              |                                |

### Security concept

### The Authentication Flow in a nutshell

OIDC is a browser-based protocol and it is what we recommend you use to authenticate and authorize browser-based applications. It makes heavy use of browser redirects to obtain an *identity* and *access* token. Here’s a brief summary:

1. Browser visits application. The application notices the user is not logged in, so it redirects the browser to Keycloak to be authenticated. The application passes along a callback URL (a redirect URL) as a query parameter in this browser redirect that Keycloak will use when it finishes authentication.
2. Keycloak authenticates the user and creates a one-time, very short lived, temporary code. Keycloak redirects back to the application using the callback URL provided earlier and additionally adds the temporary code as a query parameter in the callback URL.
3. The application extracts the temporary code and makes a background out of band REST invocation to Keycloak to exchange the code for an *identity*, *access* and *refresh* token. Once this temporary code has been used once to obtain the tokens, it can never be used again. This prevents potential replay attacks.



### LDAP Data Structure



## Release and Deployment

Artfacts overview

| Docker Container   | Sub-delivery Type           | Artifacts                                                    | Risk for damage |
| ------------------ | --------------------------- | ------------------------------------------------------------ | --------------- |
| onboarding-camunda | Application Spring Property |                                                              | Low             |
| onboarding-camunda | Java Resource               |                                                              | Medium          |
| onboarding-camunda | Java Library                | - Camunda Deployment Desc<br />- BPMN definitions<br />- CMMN definitions<br />- DMN Definitions<br />- Binaries (e.g PDF)<br />- Reference Data\*<br />- Static Web Resources\*<br />- Templates (e.g for  PDF)\*<br />- Log settings\* | High            |
| onboarding-camunda | Java Code                   | - Services<br />JSON Schemas                                 | High            |
|                    |                             |                                                              |                 |
|                    |                             |                                                              |                 |

\*Docker Container Restart required. No hot deployment supported.



### Upgrade vs. Versioning

There are two concept how we could deal with a full release with breaking api changes:

### Camunda

####  Versioning

Business Processes are by nature long running. The process instances will maybe last for weeks, or months. In the meantime the state of the process instance is stored to the database. Camunda has therefore introduced a concept which allows to run multiple versions of a process definition in parallel:

- If you redeploy a changed process definition, a new version in the database is created
- The running process instances will continue to run in the version of the process definition they were started with
- New process instances will automatically start using the latest process definition - unless specified explicitly
- Support for migrating process instances to new a version is supported within certain limits. This is crucial since   having to support multiple versions in parallel could significantly increase the support overhead!

##### Advantages

No need to upgrade existing running process when installing new release

##### Disadvantages

Since versioning is only supported by Camunda on a process definition level a strict versioning concept for code and web resources changes has to be introduced. One way to achieve that is to completely point to a versioned class and resource folder 

More details can be found [here](https://docs.camunda.org/manual/latest/user-guide/process-engine/process-versioning/)

Upgrade Process

As an alternative Camunda supports the upgrade of existing and running processes on-the-fly. In contrast to the versioning mechanism More details can be found [here](https://docs.camunda.org/manual/latest/user-guide/process-engine/process-instance-migration/).  

1. Version of the source code, web resources and binaries. Multipe 
2. Upgrade process data

#### Versioning

##### Camunda

First level: Folder named 

Docker Container Data update

Directory structure:

An archive including a folder for each container
![Release Update Package Structure](docs/store-assets/release_update_package_structure.png)

Overview of change and relase process

#### Update Release

Risk: medium

Test procedure: Regression test and deticateded testin for the changed areas

Allowed changes: 

Update Release 

1. No core changes
2. No breaking API changes

| Container          | Update Reelase | Full Release |      |
| ------------------ | -------------- | ------------ | ---- |
| onboarding-camunda | Update         | - fdef       |      |
|                    |                |              |      |
|                    |                |              |      |

Reasons for a new release

1. Bug fix
2. Security issues
3. Performance and load issues

**Application containers should not store application data**. This way you can replace the application containers with its newer version at any time.

**Upgrading applications (eg. with yum/apt-get upgrade) within containers is considered to be an anti-pattern**. 

## Miscellaneous

### Open Questions

| Question                                                     | Answer |      |
| ------------------------------------------------------------ | ------ | ---- |
| Do you agree to the release deployment process (Read chapter: Release and Deployment Process)? |        |      |
| We will enable CSRF protection on Spring Boot application Level. Is that fine with you? |        |      |
| Should we Define and reference a Content Security Policy on web server or Spring Boot application level? Probably you will want to define the CSP on WAF level. What do you think? |        |      |
| Does DECENTAGE intend intend to use a central secret storage (e.g. *docker secret*)? |        |      |

### Open Issues

| Issue                                              | Description                                                  | Prio   |
| -------------------------------------------------- | ------------------------------------------------------------ | ------ |
| Disable HTTP Session for DECENTAGE DOP                  | No HTTP Session should be created for DECENTAGE DOP since it should be completly stateless (REST calls only). Currently the JSESSIONID cookie retruned when calling DECENTAGE-dop indicates that the HTTP Session is still enabled. Only the Camunda Admin UI (/application) requires a HTTP session. | High   |
| Preferred deployment process for DECENTAGE              | There should be an flexible deployment process introduced for different deliveries, e.g:<br />onboarding-camunda<br />- Config Release (update resources in docker container)<br />- Full release (new docker image) | Medium |
| Remove all archive folders                         | All archive directories containing resources which are not used anymore have to be deleted (DECENTAGE-onboarding-process/src/main/resources/bpmn/_archive) | Medium |
| Remove keycloak certificate                        | There is still an public certificate for the jwt token validation checked in: DECENTAGE-camunda/DECENTAGE-onboarding-process/src/main/resources/public.pem. The public certificate should be loaded through from the corresponding certs endpoint for the realm. | High   |
| Move all mock classes and resources                | All classes which should never be deployed into production must be move to the project DECENTAGE-camunda/DECENTAGE-onboarding-mock. The corresponding jar is automatically removed from the package when publishing the packages tom DECENTAGE. Furthermore it would be also good to move spring classes which are excluded specifically for production through the profile annotation to the DECENTAGE-onboarding-mock project. | Medium |
| Improve development process for onboarding-camunda | Currently the Java source is compiled within the docker container. This comes with the price that a IDE can not be used and therefore a recompilation process is not automatically triggered.  A good alternative would be to use IntelliJ which is capable of hot-reloading changes directly in a docker container | Low    |
| Remove camunda legacy patch                        | With the last major update camunda had decommissioned their own JSON parser. Since we didn't had enough time to migrate code using this parser classes this should be removed soon. Otherwise we risk an unforeseen incompatibility with a future camunda release. Remove following package: *DECENTAGE-onboarding-process/src/main/java/org* and replace with an alternative JSON parser.<br />See Camunda Issue: https://app.camunda.com/jira/browse/CAM-9511 | Medium |
| Remove duplicated static file folder               | We have currently duplicated entries for the static binary files:<br />1. DECENTAGE-onboarding-process/src/main/resources/static/files<br />2. DECENTAGE-onboarding-process/src/main/resources/files<br />Remove one of either directory | Medium |
| Enable and CSRF Protection                         | Make sure CSRF protection is enabled and correctly configured in the spring camunda application (DECENTAGE-camunda):<br /><br />Since we use JavaScript framework that executes XHR calls and therefore the backend should be stateless (no HTTP Session enabled),  we probably need to configure the *CookieCsrfTokenRepository*.<br /><br />For static resources the CSRF can be disabled since only HTTP methods that modify the state *PATCH*, *POST*, *PUT*, and *DELETE* have to be protected.<br />Therefore only the following endpoints needs to protected, as:<br />/dop/*\* (?)<br /><br />/rest/\*\*(REST)<br /><br />/app/\*\* (Take special care here, this is the base path used for the Camunda cockpit, Tasklist and Admin Panel UI's and REST endpoints) | High   |
| Use a Content Security Policy                      | Spring Security provides a number of security headers by default,<br/>but not CSP. Enable it in the Spring Boot app or nginx.<br />Is only required if DECENTAGE is not using a proper WAF in front of the DECENTAGE-dop.<br />**Further clarifications with DECENTAGE is required here**. | Medium |
| Use password hashing for application properties    | We should not store passwords in plain text. We should use the PasswordEncoder for password hashing in Spring Boot.<br/>But when DECENTAGE intends uses central secret store (e.g. *docker secret*), which would anyway a better approach, since the other docker containers (e.g keycloak-gatekeeper) also would require a secrets storage mechanism, there is no need to extra hash the passwords. <br />**Further clarifications with DECENTAGE is required here**. | Medium |
| Finalize the LDAP data structure with DECENTAGE         | To increase overall security we should not use the root LDAP user, but instead introduce 2 separated LDAP users with restricted permissions. Add the following groups:<br /><br />br />br/>dn: cn=**ldap-keycloak**,ou=realm-roles,dc=DECENTAGE,dc=swiss<br/>objectclass: top<br/>objectclass: groupOfNames<br/>cn: **ldap-keycloak**<br/>member:<br /><br />This user should have **all** CRUD permissions to access:<br />-*dn: ou=users,dc=DECENTAGE,dc=swiss*<br /><br />and<br /><br />-*dn: ou=groups,dc=DECENTAGE,dc=swiss*<br /><br />dn: cn=**ldap-camunda,**ou=realm-roles,dc=DECENTAGE,dc=swiss<br/>objectclass: top<br/>objectclass: groupOfNames<br/>cn: **ldap-camunda**<br/>member:<br/><br /><br />This user should have **read-only** permissions to access:<br />-*dn: ou=users,dc=DECENTAGE,dc=swiss*<br /><br />and<br /><br />-*dn: ou=groups,dc=DECENTAGE,dc=swiss*<br /><br /> | High   |
| Update all dependencies to latest stable version   | Make sure to update the npm and maven dependencies to the latest stable version. Make sure the versions are all consistent (avoid version conflict between dependencies) | LOW    |
| Verify dependencies for known vulnerabilities      | Ensure that the dependencies used in the maven and npm descriptor used in DECENTAGE-camunda respectively DECENTAGE-onboarding-sites do not use dependencies with known vulnerabilities. <br /><br />We should use a tool like Snyk to:<br/>1. Test our app dependencies for known vulnerabilities.<br/>2. Automatically Fix issues that exist<br/>3. Continuously Monitor for new vulnerabilities<br /><br />Easiest would be to integrate [Synk's CLI](https://snyk.io/test/). it directly into the build process. <br />The global npm dependency can be used to execute a command *synk test* as a last step in the build plans:<br />[DECENTAGE-onboarding-camunda](https://bamboo.decentage.io/browse/DECENTAGE-DECENTAGE)<br /><br />[DECENTAGE-onboarding-nginx](https://bamboo.decentage.io/browse/DECENTAGE-SOS)<br /><br />Synk requires to create an account in order to test dependencies. The **FREE** plan should be sufficient for this purpose: https://snyk.io/plans/ | High   |
| Enable CORS protection                             | **DECENTAGE-camunda**<br />Since we are calling our REST services from the same domain we can disallow CORS requests completely in the spring boot security config (DECENTAGE-camunda).<br /><br />**keycloak-gatekeeper**<br />I have introduced already two environment variable in our *docker-compose.yml* files to define the CORS behavior:<br /><br />include1. *DECENTAGE_DOP_GATEKEEPER_CORS_ORIGNS* for command argument argument *--cors-origins*<br /><br />2. *DECENTAGE_DOP_GATEKEEPER_CORS_METHODS* for command argument argument *--cors-methods*<br /><br />It should be sufficient to only update the following docker environment variables:<br /> <br />DECENTAGE_DOP_GATEKEEPER_CORS_ORIGNS:=**${DECENTAGE_DOP_GATEKEEPER_BASE_URL}**<br />See details on how to configure CORS for keycloak-gatekeeper [here](https://github.com/keycloak/keycloak-documentation/blob/master/securing_apps/topics/oidc/keycloak-gatekeeper.adoc#cross-origin-resource-sharing-cors).<br /><br />**The can be removed since we disallow any requests form another domain.**<br /><br />**keycloak**<br /><br />Make sure that we limit the access from ${DECENTAGE_DOP_GATEKEEPER_BASE_URL}<br /><br />Example:<br />"webOrigins": [<br/>        "${DECENTAGE_DOP_GATEKEEPER_BASE_URL}"<br/>      ],<br /><br />This can be configured in the client configuration **DECENTAGE-keycloak-gatekeeper** found in the realm **DECENTAGE-dop** | HIGH   |
| Terminate session when calling logout              | The keycloak-gatekeeper has a well-defined endpoint (*/oauth/logout*) to logout to terminate the SSO session within keycloak-gatekeeper and afterwards delegates the  logout to keycloak (*/auth/realms/{realm-name}/protocol/openid-connect/logout*)<br /><br /><br />Since we should also terminate the HTTP session (in case of the camunda cockpit/admin panel. One way to achieve this is to define as the logoutSuccessUrlcall the gatekeeper logout endpoint (*/oauth/logout*). The logout button/link should than trigger the spring logout endpoint (in our case: */camunda/logou*t) to initiate the logout process.<br /><br />See details on how to configure the logout for keycloak-gatekeeper [here](https://github.com/keycloak/keycloak-documentation/blob/master/securing_apps/topics/oidc/keycloak-gatekeeper.adoc#logout-endpoint).Only allow service | Medium |
| Restrict resource access on keycloak-gatekeeper    | The resource should be restricted according to the specified atributes **Path**, **HTTP method** and  **Required Role**  as described in the chapter **REST services in Use**.<br /><br />Restrict all path behind "/app" to "camunda-admin" | HIGH   |

### Security Issues

|Issue                                      |Description                                                                                                                                                            |Prio|
|:------------------------------------------|:----------------------------------------------------------------------------------------------------------------------------------------------------------------------|:---|
|Current jackson library has security issues|The synk has detected security issues for java libary "jackson-databind:2.9.9.3" has currently. Currently there is now minor fix available wich is compatible with the current camunda version.|High|

### Performance considerations

| Consideration                                       | Container          | Description                                                  |        |
| --------------------------------------------------- | ------------------ | ------------------------------------------------------------ | ------ |
| Disable authentication for static resources         | onboarding-camunda | Permit all static resources in spring security configuration to avoid having to trigger verification process of the JWT token and and create a new authentication context (since HTTP Session will be disabled) on every request for static resources. | Medium |
| Cache static resources in nginx                     | onboarding-nginx   | If static resources are not cached on a preceding web server within the colocation center of DECENTAGE we should enable in the nginx web server. See details [here](https://docs.nginx.com/nginx/admin-guide/content-cache/content-caching/). Furthermore we should set the browser caching headers here to optimize browser caching. To purge the cache at anytime on a test or even productive system we have to set the **proxy_cache_purge** in the nginx configuration. Restrict the HTTP method PURGE in the onboarding-gatekeeper to a dedicated group/role (e.g. **DECENTAGE-maintenance**) to avoid unwanted purge requests from an unauthorized user. | Medium |
| Reduce serialization overhead for process variables | onboarding-camunda | We should make sure to reduce the overhead for serialization/deserialization process variables used within the tasks to a minimum:<br /><br />1.  Only map objects into a task that are essentially used to fulfill the work for this step. As an alternative the Process Data object can be split into separate variables.<br /><br />2. Either load global objects only once through JS and store them client side or outsource them to a separate REST service.<br />3.  Never store binaries in process variables | Low    |

### Docker considerations

| Consideration                                                | Container | Description |      |
| ------------------------------------------------------------ | --------- | ----------- | ---- |
| Make sure you are using volumes **for all** the persistent data (configuration, logs, database or application data) which you store on the containers | All       |             |      |
|                                                              |           |             |      |
|                                                              |           |             |      |

## 





