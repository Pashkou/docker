#!/bin/bash -e
echo "Removing all docker images..."
docker rmi $(docker images -q)