#!/bin/bash -e
ROOT_DIR=$(cd "$(dirname "$0")/.." && pwd -P);
echo ROOT_DIR=${ROOT_DIR}
echo "APP_SUBDOMAIN=${APP_SUBDOMAIN}"
cd ${ROOT_DIR}

set +e
sudo systemctl stop DECENTAGE-dop.service
set -e

docker-compose rm -s -f -v
# docker system prune --all --force
# docker volume prune --force

sleep 5
sudo rm -f ${ROOT_DIR}/.env
sudo ln -v ${ROOT_DIR}/hosts/${APP_SUBDOMAIN}.${APP_DOMAIN}/.env ${ROOT_DIR}/.env
sudo cp -fv $ROOT_DIR/service/systemd/DECENTAGE-dop.service /etc/systemd/system

sudo systemctl daemon-reload
sudo systemctl enable DECENTAGE-dop.service
sudo systemctl start DECENTAGE-dop.service
#set +e

#cd ${ROOT_DIR}/environments/prod
# docker-compose up -d
sleep 50

sudo systemctl start cf-${APP_SUBDOMAIN}.service
sudo systemctl start cf-${APP_SUBDOMAIN}-keycloak.service
set -e