#!/bin/bash -e
ROOT_DIR=$(cd "$(dirname "$0")/.." && pwd -P);
echo ROOT_DIR=${ROOT_DIR}
cd ${ROOT_DIR}
rm -f ${ROOT_DIR}/.env
ln -v ${ROOT_DIR}/hosts/localhost/.env ${ROOT_DIR}/.env
docker-compose --file docker-compose.localhost.yml --log-level INFO up --build